1. Prerequisites:
----------------
- Java 8
- Apache Maven 3.2.3 or later


2. Compile:
-----------
mvn clean install

3. Execute:
-----------
java -jar target/textcalculator-1.0-SNAPSHOT.jar



