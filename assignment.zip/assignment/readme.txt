Compile:
-------- 
mvn clean install

Execute:
-------
java -jar target/assignment-1.0-SNAPSHOT.jar Apples Milk

Or 

java -cp target/assignment-1.0-SNAPSHOT.jar com.bjss.assignment.PriceBasket Apples Milk
